const buttonColors = ["red", "blue", "green", "yellow"];
const gamePattern = [];
var userClickedPattern = [];
var starter = false;
var level = 0;

$(document).keypress(function(){

    if (!starter) {
        starter = true;
        $("#level-title").text("Level " + level);
        nextSequence();
    }
});

// $("HTML element").click(function() or no arguments is also fine)
//When any element having .btn class is hovered over, click is called. On the click, function is triggered.
$(".btn").click(function(){

    var userChosenColour = $(this).attr("id");
    userClickedPattern.push(userChosenColour);
    //console.log(userClickedPattern);
    animatePress(userChosenColour);
    playSound(userChosenColour);
 
});


function nextSequence(){
    
    level ++;
    $("#level-title").text("Level " + level);
    
    var randomNumber = Math.floor(Math.random() * 3);
    var randomChosenColour = buttonColors[randomNumber];
    gamePattern.push(randomChosenColour);
    //console.log(randomChosenColour)

    //add animation to buttons
    $("#" + randomChosenColour).fadeIn(100).fadeOut(100).fadeIn(100);

    playSound(randomChosenColour)
   
}

function playSound(name){

    var audio = new Audio("sounds/" + name + ".mp3");
    audio.play(); 

}

function animatePress(currentColour){

    //add animation from CSS
    $("#" + currentColour).addClass("pressed");

    //remove animation from CSS after 100 ms
    setTimeout(function() {
        $("#" + currentColour).removeClass("pressed")
    }, 100);
}



